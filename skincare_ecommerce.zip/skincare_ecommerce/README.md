# GlowMart — Skincare E-Commerce Website

A full e-commerce site for skincare products, built with **Django + MySQL + Bootstrap + Stripe**.

Includes: product browsing & filters (brand, category, skin type, concern, price), product
detail pages with reviews/ratings, a skin-type quiz that recommends products, cart, wishlist,
Stripe checkout, order history, and a full Django admin panel to manage everything.

> **Note on images/brands:** Brand names (Dermaco, FoxTale, Minimalist, Cetaphil, Pilgrim, Plum,
> Mamaearth) are used as text for a realistic learning/portfolio project. Product images are
> placeholders — swap them with your own photos before showing this off publicly, since real
> brand product photography is copyrighted.

---

## 1. Requirements

- Python 3.10+
- MySQL Server installed and running
- pip

## 2. Setup

```bash
# 1. Create and activate a virtual environment
python -m venv venv
source venv/bin/activate      # Windows: venv\Scripts\activate

# 2. Install dependencies
pip install -r requirements.txt
```

### MySQL setup

Open MySQL and create the database:

```sql
CREATE DATABASE skincare_db;
```

Then either edit the `DATABASES` block directly in `skincare_ecommerce/settings.py`, or set
environment variables before running the server:

```bash
export DB_NAME=skincare_db
export DB_USER=root
export DB_PASSWORD=yourpassword
export DB_HOST=localhost
export DB_PORT=3306
```

(On Windows, use `set` instead of `export`.)

### Stripe setup (test mode — free)

1. Create a free account at https://dashboard.stripe.com/register
2. Go to **Developers → API keys**
3. Copy your test **Publishable key** and **Secret key**
4. Set them as environment variables, or paste directly into `settings.py`:

```bash
export STRIPE_PUBLIC_KEY=pk_test_xxxxxxxx
export STRIPE_SECRET_KEY=sk_test_xxxxxxxx
```

Use Stripe's test card `4242 4242 4242 4242`, any future expiry date, any CVC, to simulate a
successful payment.

## 3. Run migrations & seed sample data

```bash
python manage.py makemigrations store
python manage.py migrate
python manage.py seed_data          # loads sample brands/categories/products
python manage.py createsuperuser    # create your admin login
```

## 4. Run the server

```bash
python manage.py runserver
```

Visit:
- **Site**: http://127.0.0.1:8000/
- **Admin panel**: http://127.0.0.1:8000/admin/

## 5. Project structure

```
skincare_ecommerce/
├── manage.py
├── requirements.txt
├── skincare_ecommerce/        # project settings, urls
│   ├── settings.py
│   └── urls.py
├── store/                     # main app
│   ├── models.py              # Brand, Category, Product, Cart, Order, Review, Wishlist
│   ├── views.py                # all page logic
│   ├── urls.py
│   ├── admin.py                # admin panel config
│   └── management/commands/seed_data.py
├── templates/
│   ├── base.html               # navbar, footer, layout
│   └── store/                  # all page templates
└── static/store/css/style.css  # custom skincare-themed styling
```

## 6. Where to go next (once the core works)

- Replace placeholder images with real photos (`Product.image` field, upload via admin)
- Add pagination to the product listing page
- Add "Buy Now" quick-checkout (skip cart)
- Add email confirmation on order placement (Django's email backend + Celery for background sending)
- Deploy: Render / Railway (with a hosted MySQL add-on) or PythonAnywhere

## 7. Common issues

| Problem | Fix |
|---|---|
| `Error loading MySQLdb module` | Run `pip install mysqlclient`. On Mac: `brew install mysql-client` first. On Linux: `sudo apt install default-libmysqlclient-dev` first. |
| `Access denied for user` | Double check `DB_USER` / `DB_PASSWORD` match your MySQL setup. |
| Stripe checkout fails | Make sure you pasted **test mode** keys (start with `pk_test_` / `sk_test_`), not live keys. |
| Static files/CSS not loading | Make sure `DEBUG = True` while developing; run `python manage.py collectstatic` before deploying. |

import stripe
from django.conf import settings
from django.contrib import messages
from django.contrib.auth import login
from django.contrib.auth.decorators import login_required
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User
from django.db.models import Q
from django.shortcuts import render, redirect, get_object_or_404
from django.views.decorators.http import require_POST

from .models import (
    Brand, Category, Product, Review, Cart, CartItem,
    Order, OrderItem, Wishlist, SKIN_TYPE_CHOICES, CONCERN_CHOICES,
)

stripe.api_key = settings.STRIPE_SECRET_KEY


# ---------------------------------------------------------------------
# HOME
# ---------------------------------------------------------------------
def home(request):
    featured_products = Product.objects.filter(is_featured=True)[:8]
    brands = Brand.objects.all()[:8]
    categories = Category.objects.all()
    new_arrivals = Product.objects.all()[:8]
    context = {
        'featured_products': featured_products,
        'brands': brands,
        'categories': categories,
        'new_arrivals': new_arrivals,
    }
    return render(request, 'store/home.html', context)


# ---------------------------------------------------------------------
# PRODUCT LISTING + FILTERS
# ---------------------------------------------------------------------
def product_list(request):
    products = Product.objects.all()

    query = request.GET.get('q')
    brand_slug = request.GET.get('brand')
    category_slug = request.GET.get('category')
    skin_type = request.GET.get('skin_type')
    concern = request.GET.get('concern')
    min_price = request.GET.get('min_price')
    max_price = request.GET.get('max_price')
    sort = request.GET.get('sort')

    if query:
        products = products.filter(
            Q(name__icontains=query) |
            Q(brand__name__icontains=query) |
            Q(description__icontains=query) |
            Q(ingredients__icontains=query)
        )
    if brand_slug:
        products = products.filter(brand__slug=brand_slug)
    if category_slug:
        products = products.filter(category__slug=category_slug)
    if skin_type:
        products = products.filter(skin_type=skin_type)
    if concern:
        products = products.filter(concern=concern)
    if min_price:
        products = products.filter(price__gte=min_price)
    if max_price:
        products = products.filter(price__lte=max_price)

    if sort == 'price_low':
        products = products.order_by('price')
    elif sort == 'price_high':
        products = products.order_by('-price')
    elif sort == 'newest':
        products = products.order_by('-created_at')

    context = {
        'products': products,
        'brands': Brand.objects.all(),
        'categories': Category.objects.all(),
        'skin_types': SKIN_TYPE_CHOICES,
        'concerns': CONCERN_CHOICES,
        'selected_brand': brand_slug,
        'selected_category': category_slug,
        'selected_skin_type': skin_type,
        'selected_concern': concern,
        'query': query or '',
    }
    return render(request, 'store/product_list.html', context)


def product_detail(request, slug):
    product = get_object_or_404(Product, slug=slug)
    related_products = Product.objects.filter(category=product.category).exclude(id=product.id)[:4]
    reviews = product.reviews.all()
    in_wishlist = False
    if request.user.is_authenticated:
        in_wishlist = Wishlist.objects.filter(user=request.user, product=product).exists()

    if request.method == 'POST' and request.user.is_authenticated:
        rating = request.POST.get('rating')
        comment = request.POST.get('comment', '')
        if rating:
            Review.objects.update_or_create(
                product=product, user=request.user,
                defaults={'rating': int(rating), 'comment': comment}
            )
            messages.success(request, 'Thanks for your review!')
            return redirect('product_detail', slug=slug)

    context = {
        'product': product,
        'related_products': related_products,
        'reviews': reviews,
        'in_wishlist': in_wishlist,
    }
    return render(request, 'store/product_detail.html', context)


# ---------------------------------------------------------------------
# SKIN QUIZ
# ---------------------------------------------------------------------
def skin_quiz(request):
    result_products = None
    if request.method == 'POST':
        skin_type = request.POST.get('skin_type')
        concern = request.POST.get('concern')
        result_products = Product.objects.filter(skin_type__in=[skin_type, 'all'])
        if concern:
            result_products = result_products.filter(concern=concern)
        result_products = result_products[:8]

    context = {
        'skin_types': SKIN_TYPE_CHOICES,
        'concerns': CONCERN_CHOICES,
        'result_products': result_products,
    }
    return render(request, 'store/quiz.html', context)


# ---------------------------------------------------------------------
# CART
# ---------------------------------------------------------------------
@login_required
def cart_view(request):
    cart, _ = Cart.objects.get_or_create(user=request.user)
    return render(request, 'store/cart.html', {'cart': cart})


@login_required
@require_POST
def add_to_cart(request, product_id):
    product = get_object_or_404(Product, id=product_id)
    cart, _ = Cart.objects.get_or_create(user=request.user)
    item, created = CartItem.objects.get_or_create(cart=cart, product=product)
    if not created:
        item.quantity += 1
    item.save()
    messages.success(request, f'{product.name} added to cart.')
    return redirect(request.META.get('HTTP_REFERER', 'product_list'))


@login_required
@require_POST
def update_cart_item(request, item_id):
    item = get_object_or_404(CartItem, id=item_id, cart__user=request.user)
    quantity = int(request.POST.get('quantity', 1))
    if quantity <= 0:
        item.delete()
    else:
        item.quantity = quantity
        item.save()
    return redirect('cart_view')


@login_required
def remove_from_cart(request, item_id):
    item = get_object_or_404(CartItem, id=item_id, cart__user=request.user)
    item.delete()
    messages.info(request, 'Item removed from cart.')
    return redirect('cart_view')


# ---------------------------------------------------------------------
# WISHLIST
# ---------------------------------------------------------------------
@login_required
def wishlist_view(request):
    items = Wishlist.objects.filter(user=request.user)
    return render(request, 'store/wishlist.html', {'items': items})


@login_required
def toggle_wishlist(request, product_id):
    product = get_object_or_404(Product, id=product_id)
    wishlist_item, created = Wishlist.objects.get_or_create(user=request.user, product=product)
    if not created:
        wishlist_item.delete()
        messages.info(request, 'Removed from wishlist.')
    else:
        messages.success(request, 'Added to wishlist.')
    return redirect(request.META.get('HTTP_REFERER', 'product_list'))


# ---------------------------------------------------------------------
# CHECKOUT + STRIPE
# ---------------------------------------------------------------------
@login_required
def checkout(request):
    cart, _ = Cart.objects.get_or_create(user=request.user)
    if not cart.items.exists():
        messages.warning(request, 'Your cart is empty.')
        return redirect('product_list')

    if request.method == 'POST':
        order = Order.objects.create(
            user=request.user,
            full_name=request.POST.get('full_name'),
            email=request.POST.get('email'),
            phone=request.POST.get('phone'),
            address=request.POST.get('address'),
            city=request.POST.get('city'),
            pincode=request.POST.get('pincode'),
            total_amount=cart.total_price,
        )
        for item in cart.items.all():
            OrderItem.objects.create(
                order=order,
                product=item.product,
                product_name=item.product.name,
                price=item.product.final_price,
                quantity=item.quantity,
            )

        # Create a Stripe Checkout Session (test mode)
        try:
            session = stripe.checkout.Session.create(
                payment_method_types=['card'],
                line_items=[{
                    'price_data': {
                        'currency': 'inr',
                        'product_data': {'name': item.product.name},
                        'unit_amount': int(item.product.final_price * 100),
                    },
                    'quantity': item.quantity,
                } for item in cart.items.all()],
                mode='payment',
                success_url=request.build_absolute_uri(f'/orders/{order.id}/success/'),
                cancel_url=request.build_absolute_uri('/checkout/'),
            )
            order.stripe_payment_id = session.id
            order.save()
            cart.items.all().delete()
            return redirect(session.url)
        except Exception as e:
            messages.error(request, f'Payment setup failed: {e}. (Add real Stripe test keys in settings.py)')
            return redirect('checkout')

    return render(request, 'store/checkout.html', {'cart': cart, 'stripe_public_key': settings.STRIPE_PUBLIC_KEY})


@login_required
def order_success(request, order_id):
    order = get_object_or_404(Order, id=order_id, user=request.user)
    order.status = 'paid'
    order.save()
    return render(request, 'store/order_success.html', {'order': order})


@login_required
def order_history(request):
    orders = Order.objects.filter(user=request.user)
    return render(request, 'store/order_history.html', {'orders': orders})


# ---------------------------------------------------------------------
# AUTH
# ---------------------------------------------------------------------
def signup(request):
    if request.method == 'POST':
        form = UserCreationForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            Cart.objects.get_or_create(user=user)
            messages.success(request, 'Account created! Welcome to GlowMart.')
            return redirect('home')
    else:
        form = UserCreationForm()
    return render(request, 'store/signup.html', {'form': form})

from django.core.management.base import BaseCommand
from store.models import Brand, Category, Product


class Command(BaseCommand):
    help = "Seed the database with sample skincare brands, categories, and products"

    def handle(self, *args, **kwargs):
        brands_data = ["Dermaco", "FoxTale", "Minimalist", "Cetaphil", "Pilgrim", "Plum", "Mamaearth"]
        categories_data = ["Face Wash", "Moisturizer", "Serum", "Sunscreen", "Lip Care", "Body Care"]

        brands = {}
        for name in brands_data:
            brand, _ = Brand.objects.get_or_create(name=name)
            brands[name] = brand

        categories = {}
        for name in categories_data:
            cat, _ = Category.objects.get_or_create(name=name)
            categories[name] = cat

        products_data = [
            ("Dermaco", "Face Wash", "Salicylic Acid Acne Face Wash", 399, 349, "oily", "acne",
             "Salicylic Acid, Tea Tree Oil"),
            ("Dermaco", "Serum", "Niacinamide 10% Serum", 599, None, "oily", "acne",
             "Niacinamide, Zinc"),
            ("FoxTale", "Serum", "Dewy Skin Vitamin C Serum", 795, 695, "all", "dullness",
             "Vitamin C, Ferulic Acid"),
            ("FoxTale", "Moisturizer", "Barrier Repair Ceramide Cream", 850, None, "dry", "hydration",
             "Ceramides, Squalane"),
            ("Minimalist", "Serum", "Hyaluronic Acid 2% + B5 Serum", 549, 499, "dry", "hydration",
             "Hyaluronic Acid, Vitamin B5"),
            ("Minimalist", "Sunscreen", "SPF 50 PA++++ Sunscreen", 449, None, "all", "sun_protection",
             "Zinc Oxide, Niacinamide"),
            ("Cetaphil", "Face Wash", "Gentle Skin Cleanser", 445, 399, "sensitive", "hydration",
             "Glycerin, Panthenol"),
            ("Cetaphil", "Moisturizer", "Moisturizing Lotion", 599, None, "dry", "hydration",
             "Glycerin, Vitamin B5"),
            ("Pilgrim", "Serum", "Korean Ginseng Face Serum", 449, 399, "all", "anti_aging",
             "Ginseng, Niacinamide"),
            ("Pilgrim", "Lip Care", "Kokum Butter Lip Balm", 249, None, "all", "hydration",
             "Kokum Butter, Shea Butter"),
            ("Plum", "Face Wash", "Green Tea Pore Cleansing Face Wash", 345, 299, "oily", "acne",
             "Green Tea, Salicylic Acid"),
            ("Plum", "Sunscreen", "3-in-1 Bright Days Sunscreen SPF 50", 595, None, "all", "sun_protection",
             "Vitamin C, SPF 50"),
            ("Mamaearth", "Moisturizer", "Vitamin C Daily Glow Moisturizer", 399, 349, "all", "dullness",
             "Vitamin C, Turmeric"),
            ("Mamaearth", "Sunscreen", "Ultra Light Sunscreen SPF 50", 349, None, "all", "sun_protection",
             "Turmeric, SPF 50"),
        ]

        for brand_name, cat_name, name, price, discount, skin_type, concern, ingredients in products_data:
            Product.objects.get_or_create(
                name=name,
                brand=brands[brand_name],
                defaults=dict(
                    category=categories[cat_name],
                    description=f"{name} by {brand_name} — formulated for {skin_type} skin, "
                                 f"targeting {concern.replace('_', ' ')}. Dermatologically tested.",
                    ingredients=ingredients,
                    skin_type=skin_type,
                    concern=concern,
                    price=price,
                    discount_price=discount,
                    is_featured=(price and int(price) % 2 == 0),
                    image_url=f"https://placehold.co/400x400/f6ece6/2b2420?text={name.replace(' ', '+')}",
                )
            )

        self.stdout.write(self.style.SUCCESS(
            f"Seeded {len(brands_data)} brands, {len(categories_data)} categories, {len(products_data)} products."
        ))
